log_info("akhenaten: pharaoh_custom_pack started")

pharaoh_custom_pack = [
	{ name:"commerce", prefix:"Commerce_", start_index:1, finish_index: 1 }
]
